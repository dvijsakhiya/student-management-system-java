
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;

import java.sql.Connection ;
import java.sql.DriverManager;
/**
 *
 * @author tusha
 */
public class ConnectionProvider {
    public static Connection getCon()
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "System", "dvij");
            return con;
        }
        catch(Exception e)
        {
            System.out.println(e);
            return null ;
        }
    }
}
